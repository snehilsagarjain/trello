// Sidebar.js
import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import "./sidebar.css";

const Sidebar = () => {
  const [isOpen, setIsOpen] = useState(true);
  const toggleSidebar = () => { setIsOpen(!isOpen); };
  return (
    <div>
      <div>
        <span>Trello Workspace</span>
        <button onClick={toggleSidebar}> {'>'} </button>
      </div>
      <div className={`sidebar ${isOpen ? 'open' : 'closed'}`}>

        <ul>
          <li><Link to="/boards">Boards</Link></li>
          <li><Link to="/members">Members</Link></li>
          <li><Link to="/workspace">Workspace settings</Link></li>
          <li><Link to="/contact">My Trello Board</Link></li>
        </ul>
      </div>
    </div>
  );
};
// Toggle Sidebar
export default Sidebar;