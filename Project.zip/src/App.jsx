// Filename - App.js
import React, { useEffect, useState } from 'react';
import List from './List';
// import LoginForm from './Login';
import Demo from './Login';
// import Login from './Login';
// import CircleLetterLogo from "./Login";
import { BrowserRouter, Navigate, Route, Routes } from 'react-router-dom';
import Newlist from './newlist';
import Page from "./page";
function App() {
  const abc = () => {
    console.log("8")
    return localStorage.getItem('user') === 'true'
  }
  const ProtectedRoute = (element) => {
    console.log("11")
    return abc() ? element : <Navigate to='/login' />
  }
  // const id = localStorage.getItem('user');
  return (
    <div className="App">
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<h1>{"/ location "}</h1>} />
          {/* <Route path="/login" element={<LoginForm />} /> */}
          <Route path="/login" element={<Demo />} />
          {/* <Route path="/login" element={<CircleLetterLogo />} /> */}
          {/* <Route path="/login" element={<Login />} /> */}
          {/* <Route path="/ls" element={<List />} /> */}
          <Route path="/ls" element={<Newlist />} />
          <Route path="/page" element={<Page />} />
          {/* <Route path="/ls" element={ProtectedRoute({ List })}> </Route>
          <Route path="/list" element={ProtectedRoute({ List })}> </Route> */}

          {/* <Route path="/education" element={ProtectedRoute({ Education })}> </Route> */}
          {/* <Route path="/signup" element={<Signup />} /> */}
          {/* </Route> */}
        </Routes>
      </BrowserRouter>
    </div>
  );
}

export default App;