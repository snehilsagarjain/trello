// App.js
import React from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import Sidebar from './sidebar';
import Newlist from "./newlist";
function Page() {
  return (
    // <Router>
      <div>
        <Sidebar />
        <div className="page-content">
            <Newlist />
          {/* <Routes>
            <Route path="/boards" element={<h1>Boards Page</h1>} />
            <Route path="/members" element={<h1>Members Page</h1>} />
            <Route path="/workspace" element={<h1>Workspace Page</h1>} />
            <Route path="/contact" element={<h1>Contact Page</h1>} />
          </Routes> */}
        </div>
      </div>
    // </Router>
  );
}

export default Page;
